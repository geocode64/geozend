-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 06, 2014 at 09:51 AM
-- Server version: 5.5.29
-- PHP Version: 5.3.10-1ubuntu3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `square`
--

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `CountryID` int(11) NOT NULL AUTO_INCREMENT,
  `CountryName` varchar(255) NOT NULL,
  PRIMARY KEY (`CountryID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`CountryID`, `CountryName`) VALUES
(1, 'United States'),
(2, 'United Kingdom'),
(3, 'India'),
(4, 'Singapore'),
(5, 'Germany'),
(6, 'France'),
(7, 'Italy'),
(8, 'Spain'),
(9, 'Hungary');

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

CREATE TABLE IF NOT EXISTS `family` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `familyname` varchar(255) NOT NULL,
  `code` varchar(60) DEFAULT NULL,
  `famcat` int(9) DEFAULT NULL,
  `primary_contact` int(9) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=598 ;

--
-- Dumping data for table `family`
--

INSERT INTO `family` (`fid`, `familyname`, `code`, `famcat`, `primary_contact`) VALUES
(498, '', '2B6fFqICrJ', 0, 940),
(499, '', 'ABY1T&&u90', 1, 941),
(500, '', 'ZEPGeerM8y', 4, 944),
(501, '', 'M5tL619Pj*', 1, 945),
(502, '', '6Gnzmf?xtA', 1, 947),
(503, '', '6V&IfWOTOF', 1, 949),
(504, '', '7Ti6MRWbGp', 1, 951),
(505, '', '*9ZC#s?KkC', 1, 953),
(506, '', 'isI5Y?bFfA', 1, 955),
(507, '', 'DkUdAEVGj)', 1, 956),
(508, '', '5jZIa?G13b', 1, 958),
(509, '', 'Q6IP1)gMFm', 1, 959),
(510, '', 'eiVbg4Ms50', 1, 961),
(511, '', 'z192TqkfNo', 1, 963),
(512, '', 'rXLSm5c6M)', 1, 966),
(513, '', '5wPcBEuigh', 1, 968),
(514, '', 'h7mrMos#rC', 1, 970),
(515, '', 'IV7Q*4Y)iH', 1, 971),
(516, '', 'd8()SENZSq', 1, 973),
(517, '', 'toBT1aJd2s', 1, 975),
(518, '', 'GAO5*5LbF1', 1, 977),
(519, '', 'LEsSQ&*u86', 1, 979),
(520, '', 'RrC$X&HCof', 1, 981),
(521, '', 'nnpI195CK6', 1, 983),
(522, '', 'eRBT2Syx3j', 1, 985),
(523, '', '$Mb$6DDX(g', 1, 987),
(524, '', 'y4oDCilg0T', 1, 988),
(525, '', 'mGHzAb$Ar(', 1, 989),
(526, '', 'q9ADjdUB$B', 1, 991),
(527, '', 'h1ISiDpJ#U', 1, 993),
(528, '', 'FMPoy?J2ne', 1, 995),
(529, '', 'ODG56VMq7t', 1, 997),
(530, '', '3&FmfIWYyG', 1, 999),
(531, '', 'hg9BMt7O(C', 1, 1000),
(532, '', 'iKmI&79ZPA', 1, 1002),
(533, '', 'b2N(1EqfeF', 1, 1004),
(534, '', 'M3fP1bNyhg', 1, 1006),
(535, '', '*Egs3UzmYd', 2, 1009),
(536, '', '2wXA?1$y0H', 2, 1010),
(537, '', 'jplqKbDiRz', 2, 1012),
(538, '', '$XNOTM3&#i', 2, 1014),
(539, '', 'L538RewXX#', 2, 1016),
(540, '', 'KnPjRCkD0N', 3, 1018),
(541, '', 'TR$CWz7vmX', 3, 1020),
(542, '', 'Up9gdx0T6N', 3, 1022),
(543, '', 'Gqu8h#DY6d', 3, 1024),
(544, '', 'v&lfRUjCNT', 3, 1026),
(545, '', '8t0MkO7(Lb', 3, 1028),
(546, '', 'Ueqh*fdbZG', 3, 1030),
(547, '', 'n$?NQR5&hl', 3, 1032),
(548, '', 'trJlhW?Ma2', 3, 1034),
(549, '', 'G)Y&o#O6Nl', 3, 1036),
(550, '', 'J$vsZn0#Cy', 3, 1038),
(551, '', 'JyV$36YNT)', 3, 1039),
(552, '', 'tVLEmD)Q03', 3, 1041),
(553, '', 'N?h(TAU?PL', 3, 1043),
(554, '', 'zax1BGK09k', 3, 1045),
(555, '', 'w(ElYiIf5m', 3, 1047),
(556, '', 'Tq$dJSAXz0', 3, 1049),
(557, '', 'NRpPBUD#j?', 3, 1050),
(558, '', 'UWg)X8(mlj', 3, 1052),
(559, '', 'uYu6cnZcaZ', 3, 1054),
(560, '', 'ejnS01kiM4', 3, 1056),
(561, '', 'bo9IPU5))C', 3, 1058),
(562, '', 'kpa&MU6iYv', 4, 1060),
(563, '', 'hWGLkelnI#', 4, 1062),
(564, '', '9mlyEU2hO0', 4, 1062),
(565, '', 'SZT2bIjwuK', 4, 1065),
(566, '', 'OUMD8nmMWj', 4, 1067),
(567, '', 'n)EjX3paP*', 4, 1069),
(568, '', 'qc1yyb)5Ws', 4, 1071),
(569, '', 'h7QYnwovF6', 4, 1073),
(570, '', '&c158nabMV', 4, 1075),
(571, '', 'U5qENJjZB6', 4, 1077),
(572, '', 'ge9KydLMtR', 4, 1079),
(573, '', 'Y5xeUnGBDh', 4, 1079),
(574, '', 'NefU3iBpKn', 4, 1083),
(575, '', 'RQVTl$RGdY', 4, 1085),
(576, '', '(7BwAKmhbX', 5, 1087),
(577, '', 'f4DMb#J8*F', 5, 1089),
(578, '', '1spvH35brS', 5, 1091),
(579, '', 'reXsY73m7v', 5, 1093),
(580, '', 'TRk9InPXQ6', 5, 1095),
(581, '', '7*p&Tje(UK', 5, 1097),
(582, '', 'IZBYNtQyOJ', 5, 1099),
(583, '', 'KmMYH4eTCQ', 5, 1101),
(584, '', 'TzIhwVuKgB', 5, 1103),
(585, '', 'swBnjIDVPI', 5, 1105),
(586, '', 'gsducnv(5c', 5, 1107),
(587, '', 'DslOJ3sUo2', 5, 1109),
(588, '', 'bU4tpEJ67D', 5, 1111),
(589, '', 'Fog(1t#yHJ', 5, 1113),
(590, '', '7Dh)6&Odje', 5, 1115),
(591, '', 'DR8xKlkP3J', 5, 1117),
(592, '', 'T4oETAoegK', 5, 1119),
(593, '', 'B)wnLg9BJU', 5, 1121),
(594, '', '55*(461tfp', 5, 1123),
(595, '', 'BF*T#Hx0&L', 5, 1125),
(596, '', '$G#bBaXBsq', 0, 1125),
(597, '', '01E#T$&C?a', 0, 1125);

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

CREATE TABLE IF NOT EXISTS `grade` (
  `GradeID` int(11) NOT NULL AUTO_INCREMENT,
  `GradeName` varchar(255) NOT NULL,
  PRIMARY KEY (`GradeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `grade`
--

INSERT INTO `grade` (`GradeID`, `GradeName`) VALUES
(1, 'Very Fine'),
(2, 'Fine'),
(3, 'Good'),
(4, 'Average'),
(5, 'Poor');

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

CREATE TABLE IF NOT EXISTS `guest` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `fid` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `rsvp` varchar(255) NOT NULL DEFAULT 'noresponse',
  `email` varchar(256) NOT NULL,
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1129 ;

--
-- Dumping data for table `guest`
--

INSERT INTO `guest` (`gid`, `fid`, `firstname`, `lastname`, `rsvp`, `email`) VALUES
(941, 499, 'Doug', '', 'noresponse', 'gastromail@gmail.com'),
(942, 499, 'Jo', '', 'noresponse', ''),
(943, 500, 'Tamara', 'Heligman', 'noresponse', ''),
(944, 500, 'George', '', 'noresponse', 'sliiiiiide@gmail.com'),
(945, 501, 'Rob', '', 'noresponse', 'rsamuel@consultpoint.com.au'),
(946, 501, 'Ellie', '', 'noresponse', ''),
(947, 502, 'Jeremy', '', 'noresponse', 'jeremysamuel@anacacia.com.au'),
(948, 502, 'Ilana', '', 'noresponse', ''),
(949, 503, 'Colin', '', 'noresponse', 'colinsamuel@hotmail.com'),
(950, 503, 'Michelle', '', 'noresponse', ''),
(951, 504, 'Gill', '', 'noresponse', 'gillsamuel@hotmail.com'),
(952, 504, 'Andy', '', 'noresponse', ''),
(953, 505, 'Anna', '', 'noresponse', 'annagoulston@hotmail.com'),
(954, 505, 'Matt', '', 'noresponse', ''),
(955, 506, 'Kerry', '', 'noresponse', 'kerry.goulston@sydney.edu.au'),
(956, 507, 'Bar', '', 'noresponse', 'bar_co@hotmail.com'),
(957, 507, 'Tim', '', 'noresponse', ''),
(958, 508, 'Jess', '', 'noresponse', 'jesscohen58@gmail.com'),
(959, 509, 'Anna', '', 'noresponse', 'annacohen100@gmail.com'),
(960, 509, 'Russ', '', 'noresponse', ''),
(961, 510, 'Sadhana', '', 'noresponse', 'sadhana@scoastnet.com.au'),
(962, 510, 'Asanga', '', 'noresponse', ''),
(963, 511, 'Sue', '', 'noresponse', 'shallenstein@yahoo.com'),
(964, 511, 'Hal', '', 'noresponse', ''),
(965, 511, 'May', '', 'noresponse', ''),
(966, 512, 'Joe', '', 'noresponse', 'jhallenstein@gmail.com'),
(967, 512, 'Partner', '', 'noresponse', ''),
(968, 513, 'Ben', '', 'noresponse', 'bhallenstein@hotmail.com'),
(969, 513, 'Jo', '', 'noresponse', ''),
(970, 514, 'Lucie', '', 'noresponse', 'lhallenstein@gmail.com'),
(971, 515, 'Louise', '', 'noresponse', 'pvhyds@iprimus.com.au'),
(972, 515, 'Simon', '', 'noresponse', ''),
(973, 516, 'Oliver', '', 'noresponse', 'ofrankel@bigpond.net.au'),
(974, 516, 'Partner', '', 'noresponse', ''),
(975, 517, 'Gigi', '', 'noresponse', 'ginette@goulston-lincoln.com'),
(976, 517, 'Shane', '', 'noresponse', ''),
(977, 518, 'Wendy', '', 'noresponse', 'wendygoulston@gmail.com'),
(978, 518, 'Larry', '', 'noresponse', ''),
(979, 519, 'Ben', '', 'noresponse', 'bheligman@gmail.com'),
(980, 519, 'Ruthie', '', 'noresponse', ''),
(981, 520, 'Di', '', 'noresponse', 'jayzed@pipeline.com'),
(982, 520, 'Joel', '', 'noresponse', ''),
(983, 521, 'James', '', 'noresponse', 'james@akazelig.com'),
(984, 521, 'Tali', '', 'noresponse', ''),
(985, 522, 'Molly', '', 'noresponse', 'mollyrobinson@gmail.com'),
(986, 522, 'Jeff', '', 'noresponse', ''),
(987, 523, 'Amelia', '', 'noresponse', 'ameliarobinson@gmail.com'),
(988, 524, 'Sam', '', 'noresponse', 'samuelmgrobinson@gmail.com'),
(989, 525, 'Linda', '', 'noresponse', 'linbarmax@gmail.com'),
(990, 525, 'Barb', '', 'noresponse', ''),
(991, 526, 'Robyn', '', 'noresponse', 'snr711@aol.com'),
(992, 526, 'Scott', '', 'noresponse', ''),
(993, 527, 'Susan', '', 'noresponse', 'peteandsuz94@aol.com'),
(994, 527, 'Pete', '', 'noresponse', ''),
(995, 528, 'Rachel', '', 'noresponse', 'rachelshenker@gmail.com'),
(996, 528, 'Ross', '', 'noresponse', ''),
(997, 529, 'Janice', '', 'noresponse', 'janiceshenker@gmail.com'),
(998, 529, 'Mitch', '', 'noresponse', ''),
(999, 530, 'Allison', '', 'noresponse', 'allie6390@yahoo.com'),
(1000, 531, 'Marilyn', '', 'noresponse', 'mardonvan@sbcglobal.net'),
(1001, 531, 'Don', '', 'noresponse', ''),
(1002, 532, 'sue', '', 'noresponse', 'sebraham@bigpond.com'),
(1003, 532, 'mike', '', 'noresponse', ''),
(1004, 533, 'judy', '', 'noresponse', 'jbraham@orange.fr'),
(1005, 533, 'geoff', '', 'noresponse', ''),
(1006, 534, 'Tamara', '', 'noresponse', '??'),
(1007, 534, 'Steve', '', 'noresponse', ''),
(1008, 535, 'James', '', 'noresponse', ''),
(1009, 535, 'Denise', '', 'noresponse', 'denisemmetzger@gmail.com'),
(1010, 536, 'Julie', '', 'noresponse', 'justyne.desade@gmail.com'),
(1011, 536, 'Malcolm', '', 'noresponse', ''),
(1012, 537, 'ian', '', 'noresponse', '??'),
(1013, 537, 'ian'' wife', '', 'noresponse', ''),
(1014, 538, 'sean', '', 'noresponse', 'seanbarrett@bigpond.com'),
(1015, 538, 'christine', '', 'noresponse', ''),
(1016, 539, 'kate', '', 'noresponse', 'katie.bartlett@bigpond.com'),
(1017, 539, 'justin', '', 'noresponse', ''),
(1018, 540, 'Michal', '', 'noresponse', 'mtparness@gmail.com'),
(1019, 540, 'Avi', '', 'noresponse', ''),
(1020, 541, 'Adina', '', 'noresponse', 'adinaz@gmail.com'),
(1021, 541, 'David', '', 'noresponse', ''),
(1022, 542, 'Maria', '', 'noresponse', 'mia296@aol.com'),
(1023, 542, 'Eric', '', 'noresponse', ''),
(1024, 543, 'Francesca', '', 'noresponse', 'cheska7772@aol.com'),
(1025, 543, 'David', '', 'noresponse', ''),
(1026, 544, 'Aliza', '', 'noresponse', 'alizadiana@gmail.com'),
(1027, 544, 'Kenny', '', 'noresponse', ''),
(1028, 545, 'Dina', '', 'noresponse', 'dina.m.gordon@gmail.com'),
(1029, 545, 'Dave', '', 'noresponse', ''),
(1030, 546, 'Jess', '', 'noresponse', 'jessica.brand@gmail.com'),
(1031, 546, 'Chris', '', 'noresponse', ''),
(1032, 547, 'Maggie', '', 'noresponse', 'mluce@auburnschl.edu'),
(1033, 547, 'Trevor', '', 'noresponse', ''),
(1034, 548, 'Kerry', '', 'noresponse', 'kerry_salvo@yahoo.com'),
(1035, 548, 'Partner', '', 'noresponse', ''),
(1036, 549, 'Sharon', '', 'noresponse', 'sharonweiss@gmail.com'),
(1037, 549, 'Ben', '', 'noresponse', ''),
(1038, 550, 'Jen', '', 'noresponse', 'dean.jen220@gmail.com'),
(1039, 551, 'Rob', '', 'noresponse', 'hartmanrobert2@gmail.com'),
(1040, 551, 'Lisa', '', 'noresponse', ''),
(1041, 552, 'Brooke', '', 'noresponse', 'brookeannrobinson@gmail.com'),
(1042, 552, 'Partner', '', 'noresponse', ''),
(1043, 553, 'Kai', '', 'noresponse', 'ktakatsuka@gmail.com'),
(1044, 553, 'Ben', '', 'noresponse', ''),
(1045, 554, 'Robin', '', 'noresponse', 'robin.roehrborn@gmail.com'),
(1046, 554, 'Brad', '', 'noresponse', ''),
(1047, 555, 'Sara', '', 'noresponse', 'brobstsara@gmail.com'),
(1048, 555, 'Jeremiah', '', 'noresponse', ''),
(1049, 556, 'Bobbie', '', 'noresponse', 'BLeighton@opportunityalliance.org'),
(1050, 557, 'Lauren', '', 'noresponse', 'rosenblum.lauren@gmail.com'),
(1051, 557, 'Jon', '', 'noresponse', ''),
(1052, 558, 'Katie', '', 'noresponse', 'kathleenygaffney@gmail.com'),
(1053, 558, 'Partner', '', 'noresponse', ''),
(1054, 559, 'Jodut', '', 'noresponse', 'jodut.hashmi@gmail.com'),
(1055, 559, 'Ben', '', 'noresponse', ''),
(1056, 560, 'Meaghan', '', 'noresponse', 'mpatinella@gmail.com'),
(1057, 560, 'Partner', '', 'noresponse', ''),
(1058, 561, 'darcy', '', 'noresponse', 'darcy.york@gmail.com'),
(1059, 561, 'dani', '', 'noresponse', ''),
(1060, 562, 'Gill', '', 'noresponse', 'gillheydon@hotmail.com'),
(1061, 562, 'Nev', '', 'noresponse', ''),
(1062, 563, 'Alex', '', 'noresponse', 'alexheydon@hotmail.com'),
(1063, 563, 'Katrina', '', 'noresponse', ''),
(1064, 564, 'Nan', '', 'noresponse', ''),
(1065, 565, 'Brian', '', 'noresponse', 'bookerbc@bigpond.com'),
(1066, 565, 'Jan', '', 'noresponse', ''),
(1067, 566, 'Sonia', '', 'noresponse', 'twentycats@live.com'),
(1068, 566, 'Craig', '', 'noresponse', ''),
(1069, 567, 'Dave', '', 'noresponse', 'davidbbooker@gmail.com'),
(1070, 567, 'partner', '', 'noresponse', ''),
(1071, 568, 'Brooklyn', '', 'noresponse', 'suburbanreptile@live.com'),
(1072, 568, 'Carolyn', '', 'noresponse', ''),
(1073, 569, 'Maria', '', 'noresponse', 'marialouise66@bigpond.com'),
(1074, 569, 'Partner', '', 'noresponse', ''),
(1075, 570, 'Sarah', '', 'noresponse', 'sarah-owen@hotmail.com'),
(1076, 570, 'partner', '', 'noresponse', ''),
(1077, 571, 'Kylie', '', 'noresponse', 'mickandky@bigpond.com'),
(1078, 571, 'Mick', '', 'noresponse', ''),
(1079, 572, 'Colin Clayton', '', 'noresponse', 'cdclayton@hotmail.com'),
(1080, 572, 'Colin''s wife', '', 'noresponse', ''),
(1081, 573, 'Aunty Shirl', '', 'noresponse', ''),
(1082, 573, 'Uncle Ivan', '', 'noresponse', ''),
(1083, 574, 'Vanessa', '', 'noresponse', 'vanessaheydon@yahoo.com.au'),
(1084, 574, 'scott', '', 'noresponse', ''),
(1085, 575, 'Cliff', '', 'noresponse', 'albertashton@hotmail.com'),
(1086, 575, 'Aylene', '', 'noresponse', ''),
(1087, 576, 'Stevo & Nomes', '', 'noresponse', 'mrstephenafoster@gmail.com'),
(1088, 576, 'Nomes', '', 'noresponse', ''),
(1089, 577, 'Stef', '', 'noresponse', 'stefan.giameos@bigpond.com'),
(1090, 577, 'zaida', '', 'noresponse', ''),
(1091, 578, 'Palmer', '', 'noresponse', 'David.Palmer@bdo.com.au'),
(1092, 578, 'Jenna', '', 'noresponse', ''),
(1093, 579, 'Squiz', '', 'noresponse', 'tom.squier@smithsdetection.com'),
(1094, 579, 'Katrin', '', 'noresponse', ''),
(1095, 580, 'Wilcox', '', 'noresponse', 'tomwilcox@tasmarine.com.au'),
(1096, 580, 'Anna', '', 'noresponse', ''),
(1097, 581, 'hicka', '', 'noresponse', 'A.Hickton@waterway.com.au'),
(1098, 581, 'robyn', '', 'noresponse', ''),
(1099, 582, 'stu', '', 'noresponse', 'stuartplasma@gmail.com'),
(1100, 582, 'em', '', 'noresponse', ''),
(1101, 583, 'kizza', '', 'noresponse', 'Kieran.OBrien@utas.edu.au'),
(1102, 583, 'anna', '', 'noresponse', ''),
(1103, 584, 'clarkey', '', 'noresponse', 'Jason.Clark@bidvest.com.au'),
(1104, 584, 'partner', '', 'noresponse', ''),
(1105, 585, 'tom', '', 'noresponse', 'thomasjmorgan@hotmail.com'),
(1106, 585, 'claire', '', 'noresponse', ''),
(1107, 586, 'martijn', '', 'noresponse', 'm.vaneijkelenborg@gmail.com'),
(1108, 586, 'anita', '', 'noresponse', ''),
(1109, 587, 'brooksy', '', 'noresponse', 'pbrooks@rh.com.au'),
(1110, 587, 'brookys''s partner', '', 'noresponse', ''),
(1111, 588, 'chucky d', '', 'noresponse', 'charles_donnelly@hotmail.com'),
(1112, 588, 'partner', '', 'noresponse', ''),
(1113, 589, 'lehovicz', '', 'noresponse', 'christopher.lachowicz@gmail.com'),
(1114, 589, 'agata', '', 'noresponse', ''),
(1115, 590, 'jez', '', 'noresponse', 'jeremy.mcwilliams@vicbar.com.au'),
(1116, 590, 'laura', '', 'noresponse', ''),
(1117, 591, 'dave schreuder', '', 'noresponse', 'david.schreuder@dtf.vic.gov.au'),
(1118, 591, 'kelly', '', 'noresponse', ''),
(1119, 592, 'pav', '', 'noresponse', 'pavlidy@gmail.com'),
(1120, 592, 'maria', '', 'noresponse', ''),
(1121, 593, 'charlie cameron', '', 'noresponse', 'charlie1140@hotmail.com'),
(1122, 593, 'virginia', '', 'noresponse', ''),
(1123, 594, 'tom saunders', '', 'noresponse', 'thomassaunders@hotmail.com'),
(1124, 594, 'paartner', '', 'noresponse', ''),
(1125, 595, 'Pat D', '', 'noresponse', 'Patrick.Dixon@justice.tas.gov.au'),
(1126, 596, 'Erica Famous', '', 'noresponse', ''),
(1127, 596, 'Joe', '', 'noresponse', ''),
(1128, 597, 'Rebecca Brochu', '', 'noresponse', '');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `RecordID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordDate` date NOT NULL,
  `SellerName` varchar(255) NOT NULL,
  `SellerEmail` varchar(255) NOT NULL,
  `SellerTel` varchar(50) DEFAULT NULL,
  `SellerAddress` text,
  `Title` varchar(255) NOT NULL,
  `Year` int(4) NOT NULL,
  `CountryID` int(4) NOT NULL,
  `Denomination` float NOT NULL,
  `TypeID` int(4) NOT NULL,
  `GradeID` int(4) NOT NULL,
  `SalePriceMin` float NOT NULL,
  `SalePriceMax` float NOT NULL,
  `Description` text NOT NULL,
  `DisplayStatus` tinyint(1) NOT NULL,
  `DisplayUntil` date DEFAULT NULL,
  PRIMARY KEY (`RecordID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`RecordID`, `RecordDate`, `SellerName`, `SellerEmail`, `SellerTel`, `SellerAddress`, `Title`, `Year`, `CountryID`, `Denomination`, `TypeID`, `GradeID`, `SalePriceMin`, `SalePriceMax`, `Description`, `DisplayStatus`, `DisplayUntil`) VALUES
(1, '2009-12-06', 'John Doe', 'john@example.com', '+123456789102', '12 Green House, Red Road, Blue City', 'Himalayas - Silver Jubilee', 1958, 3, 5, 1, 2, 10, 15, 'Silver jubilee issue. Aerial view of snow-capped.  \r\nHimalayan mountains. Horizontal orange stripe across  \r\ntop margin. Excellent condition, no marks.', 0, NULL),
(2, '2009-10-05', 'Susan Doe', 'susan@example.com', '+198765432198', '1 Tiger Place, Animal City 648392', 'Britain - WWII Fighter', 1966, 2, 1, 1, 4, 1, 2, 'WWII Fighter Plane overlaid on blue sky. Cancelled', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `RecordID` int(11) NOT NULL AUTO_INCREMENT,
  `LogMessage` text NOT NULL,
  `LogLevel` varchar(30) NOT NULL,
  `LogTime` varchar(30) NOT NULL,
  `Stack` text,
  `Request` text,
  PRIMARY KEY (`RecordID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE IF NOT EXISTS `type` (
  `TypeID` int(11) NOT NULL AUTO_INCREMENT,
  `TypeName` varchar(255) NOT NULL,
  PRIMARY KEY (`TypeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`TypeID`, `TypeName`) VALUES
(1, 'Commemorative'),
(2, 'Decorative'),
(3, 'Definitive'),
(4, 'Special'),
(5, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `RecordID` int(4) NOT NULL AUTO_INCREMENT,
  `Username` varchar(10) NOT NULL,
  `Password` text NOT NULL,
  PRIMARY KEY (`RecordID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`RecordID`, `Username`, `Password`) VALUES
(1, 'john', '*DACDE7F5744D3CB439B40D938673B8240B824853'),
(2, 'geo', '*931B3E9BDA6E2E1E2BA717D2CB1C0EE7E187C80B');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
